import React, { useEffect, useState, useCallback, useMemo } from 'react';
import Map, { Marker, Source, Layer } from 'react-map-gl';
import { useIntl } from 'react-intl';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import useOfflineMapStyle from '../../hooks/useOfflineMapStyle';
import { MBTILES_SATELLITE_STYLE, OSM_BASIC_STYLE_URL } from '../../services/mbtilesMapStyle';
import { useLangStore } from '../../store/langStore';
import { getLocationTitleById } from '../../utils/getLocationTitle';
import { loadGeoJsonData } from '../../utils/loadGeoJsonData.js';
import { createHaramVectorTileConfig } from '../../config/vectorTiles';
import { initHaramVectorLayers } from '../../utils/initVectorLayers';

function ensureRtlOnce() {
  if (window.__RTL_PLUGIN_SET__) return;
  window.__RTL_PLUGIN_SET__ = true;
  maplibregl.setRTLTextPlugin("/rtl/mapbox-gl-rtl-text.js", undefined, true);
}

ensureRtlOnce();

const groupColors = {
  sahn: '#4caf50',
  eyvan: '#2196f3',
  ravaq: '#9c27b0',
  masjed: '#ff9800',
  madrese: '#3f51b5',
  khadamat: '#607d8b',
  elmi: '#00bcd4',
  cemetery: '#795548',
  qrcode: '#607d8b',
  elevator: '#ffc107',
  other: '#757575'
};

const nodeFunctionColors = {
  door: '#e53935'
};

const HIDDEN_VECTOR_LAYER_IDS = new Set([
  'areas-outline',
  'areas-fill',
  'areas-label',
  'doorsAccessPoint',
  'doors'
]);

const getCompositeIcon = (groups = [], group, nodeFunction, size = 35, opacity = 1) => {
  const color = nodeFunctionColors[nodeFunction] || groupColors[group] || '#999';
  let iconData =
    groups.find((g) => g.value === group) ||
    groups.find((g) => g.value === nodeFunction) ||
    groups.find((g) => g.value === 'other') || {
      icon: 'other',
      label: 'icon',
      png: undefined
    };

  return (
    <div
      style={{
        width: size,
        height: size,
        backgroundColor: color,
        opacity,
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 2px 6px rgba(0,0,0,0.3)'
      }}
    >
      <div
        className={`map-category-icon ${iconData.icon}`}
        style={{ width: '22px', height: '22px', marginTop: 0 }}
      >
        <img src={iconData.png} alt={iconData.label || 'icon'} width="22" height="22" />
      </div>
    </div>
  );
};

const Mprc = ({
  setUserLocation,
  selectedDestination,
  onMapClick,
  isSelectingLocation,
  selectedCategory,
  userLocation,
  isTracking = true,
  onUserMove,
  groups = [],
  areaDoorsData,
  showImageMarkers = false,
  landmarkPlaces = [],
  isChoosingFromMap = false,
  selectedMapType = null,
  selectedLandmarkId = null,  // NEW: Added prop
  onLandmarkSelect = () => { }, // NEW: Added prop
  onZoomChange = () => { }
}) => {
  const intl = useIntl();
  const [viewState, setViewState] = useState({
    latitude: 36.2880,  // Original shrine coordinates
    longitude: 59.6157,
    zoom: 15
  });
  const [userCoords, setUserCoords] = useState(null);
  const [destCoords, setDestCoords] = useState(null);
  const [selectedCoords, setSelectedCoords] = useState(null);
  const [pointFeatures, setPointFeatures] = useState([]);
  const [doorConnectionNodes, setDoorConnectionNodes] = useState([]);
  const [routeCoords, setRouteCoords] = useState(null);
  const language = useLangStore((state) => state.language);
  const isRtl = ["fa", "ar", "ur"].includes(language);
  const baseMapStyle = isRtl ? "./map-styles/osm-voyager/style.json" : "./map-styles/osm-voyager/style-en.json";
  const { mapStyle: offlineMapStyle, handleMapError, styleKey } = useOfflineMapStyle(baseMapStyle);
  const isSatellite = selectedMapType === 'satellite';
  const isOfflineOsmh = selectedMapType === 'simple';
  const mapStyle = isSatellite ? MBTILES_SATELLITE_STYLE : isOfflineOsmh ? OSM_BASIC_STYLE_URL : offlineMapStyle;
  const mapRenderKey = isSatellite
    ? 'mbtiles-satellite'
    : isOfflineOsmh
      ? 'mbtiles-offline-osmh'
      : `${styleKey}-${isRtl ? 'rtl' : 'en'}`;
  const vectorTileConfig = useMemo(() => {
    return createHaramVectorTileConfig(language).filter(
      (layerCfg) => !HIDDEN_VECTOR_LAYER_IDS.has(layerCfg.id)
    );
  }, [language]);

  const calculateViewForBounds = useCallback((bounds, options = {}) => {
    const { minLon, maxLon, minLat, maxLat } = bounds;
    const { width = 800, height = 600, padding = 0, maxZoom = 19 } = options;

    const latRad = (lat) => {
      const sin = Math.sin((lat * Math.PI) / 180);
      const clamped = Math.min(Math.max(sin, -0.9999), 0.9999);
      return Math.log((1 + clamped) / (1 - clamped)) / 2;
    };

    const zoomFor = (mapPx, fraction) => Math.log(mapPx / 256 / fraction) / Math.LN2;

    const paddedWidth = Math.max(width - padding * 2, 1);
    const paddedHeight = Math.max(height - padding * 2, 1);

    const latFraction = (latRad(maxLat) - latRad(minLat)) / Math.PI;
    const lngDiff = maxLon - minLon;
    const lngFraction = ((lngDiff + 360) % 360) / 360;

    const latZoom = latFraction > 0 ? zoomFor(paddedHeight, latFraction) : maxZoom;
    const lngZoom = lngFraction > 0 ? zoomFor(paddedWidth, lngFraction) : maxZoom;
    const zoom = Math.min(latZoom, lngZoom, maxZoom);

    return {
      longitude: (minLon + maxLon) / 2,
      latitude: (minLat + maxLat) / 2,
      zoom: Number.isFinite(zoom) ? zoom : maxZoom
    };
  }, []);

  const onMove = useCallback((evt) => {
    setViewState(evt.viewState);
    onZoomChange?.(evt.viewState.zoom);
    if (onUserMove && evt.originalEvent) {
      onUserMove();
    }
  }, [onZoomChange, onUserMove]);

  const handleMapLoad = useCallback((event) => {
    initHaramVectorLayers(event?.target || event, vectorTileConfig);
  }, [vectorTileConfig]);

  const extractPlaceCoordinates = useCallback((place = {}) => {
    const lat =
      place.lat ??
      place.latitude ??
      place?.location?.lat ??
      place?.geo?.lat ??
      place?.coordinates?.[0] ??
      place?.geometry?.coordinates?.[1];
    const lng =
      place.lng ??
      place.longitude ??
      place?.location?.lng ??
      place?.geo?.lng ??
      place?.coordinates?.[1] ??
      place?.geometry?.coordinates?.[0];

    if (lat == null || lng == null) return null;
    return { lat: Number(lat), lng: Number(lng) };
  }, []);

  const getFirstImage = useCallback((place) => {
    if (!place) return null;

    if (Array.isArray(place.image) && place.image.length > 0) {
      return place.image[0];
    }

    if (Array.isArray(place.images) && place.images.length > 0) {
      return place.images[0];
    }

    if (typeof place.image === 'string' && place.image.trim()) {
      return place.image;
    }

    if (typeof place.images === 'string' && place.images.trim()) {
      return place.images;
    }

    return null;
  }, []);

  const handleLandmarkClick = (event, place, coords) => {
    event?.stopPropagation?.();

    const normalizeImages = (place) => {
      if (Array.isArray(place.image)) return place.image;
      if (Array.isArray(place.images)) return place.images;

      const firstImage = getFirstImage(place);
      return firstImage ? [firstImage] : [];
    };

    const feature = {
      geometry: { type: 'Point', coordinates: [coords.lng, coords.lat] },
      properties: {
        ...place,
        name: place.title || place.name || place.subGroup,
        label: place.title || place.name || place.subGroup,
        subGroupValue: place.subGroupValue || place.value || place.id,
        img: normalizeImages(place),
        isLandmark: true,
        distance: place.distance,
        time: place.time,
        description: place.description,
        address: place.address,
        coordinates: [coords.lat, coords.lng],
        lat: coords.lat,
        lng: coords.lng,
        geo: { lat: coords.lat, lng: coords.lng }
      }
    };

    onLandmarkSelect({
      ...place,
      coordinates: [coords.lat, coords.lng],
      lat: coords.lat,
      lng: coords.lng,
      geo: { lat: coords.lat, lng: coords.lng }
    });

    onMapClick?.({ lat: coords.lat, lng: coords.lng }, feature);
  };

  // Initialize map focus and user location based on QR entry or GPS tracking
  useEffect(() => {
    const storedLat = sessionStorage.getItem('qrLat');
    const storedLng = sessionStorage.getItem('qrLng');
    const storedId = sessionStorage.getItem('qrId');

    if (storedLat && storedLng) {
      const coords = {
        lat: parseFloat(storedLat),
        lng: parseFloat(storedLng)
      };
      setUserCoords(coords);
      (async () => {
        let name = intl.formatMessage({ id: 'mapCurrentLocationName' });
        if (storedId) {
          const title = await getLocationTitleById(storedId);

          if (title) name = title;
        }
        setUserLocation({
          name,
          coordinates: [coords.lat, coords.lng]
        });
      })();
      setViewState(v => ({
        ...v,
        latitude: coords.lat,
        longitude: coords.lng,
        zoom: 18
      }));
      return; // Skip GPS if QR code exists
    }

    if (!isTracking) return undefined;

    const success = (pos) => {
      if (sessionStorage.getItem('qrLat') && sessionStorage.getItem('qrLng')) {
        return; // Don't override QR code location
      }
      const c = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude
      };
      setUserCoords(c);
      setUserLocation({
        name: intl.formatMessage({ id: 'mapCurrentLocationName' }),
        coordinates: [c.lat, c.lng]
      });
      setViewState((v) => ({
        ...v,
        latitude: c.lat,
        longitude: c.lng,
        zoom: 18
      }));
    };

    const err = (e) => {
      console.error('Error getting location', e);
    };

    navigator.geolocation.getCurrentPosition(success, err, {
      enableHighAccuracy: false,
      timeout: 10000,
      maximumAge: 60000
    });

    const watchId = navigator.geolocation.watchPosition(success, err, {
      enableHighAccuracy: false,
      maximumAge: 0,
      timeout: 10000
    });

    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, [setUserLocation, intl, isTracking]);

  // Update user location and optionally center map when it changes
  useEffect(() => {
    if (userLocation?.coordinates) {
      const [lat, lng] = userLocation.coordinates;
      const coords = { lat, lng };
      setUserCoords(coords);

      // Only center if tracking is enabled or if we're swapping
      if (isTracking || !destCoords) {
        setViewState(v => ({
          ...v,
          latitude: lat,
          longitude: lng,
          zoom: 18
        }));
      }
    }
  }, [userLocation, isTracking]);

  // Update the destination useEffect to handle swapping:
  useEffect(() => {
    if (selectedDestination?.coordinates) {
      const [lat, lng] = selectedDestination.coordinates;
      const coords = { lat, lng };
      setDestCoords(coords);

      // Only center if we don't have user coords or if we're swapping
      if (!userCoords) {
        setViewState(v => ({
          ...v,
          latitude: lat,
          longitude: lng,
          zoom: 18
        }));
      }
    } else {
      setDestCoords(null);
    }
  }, [selectedDestination]);

  // Update destination marker and center map when selection changes
  useEffect(() => {
    if (selectedDestination?.coordinates) {
      const [lat, lng] = selectedDestination.coordinates;
      const coords = { lat, lng };
      setDestCoords(coords);

      // Only center map if this is a new destination selection
      if (!destCoords || destCoords.lat !== lat || destCoords.lng !== lng) {
        setViewState(v => ({
          ...v,
          latitude: lat,
          longitude: lng,
          zoom: 18
        }));
      }
    } else {
      setDestCoords(null);
    }
  }, [selectedDestination]);

  useEffect(() => {
    if (!Array.isArray(areaDoorsData?.doors) || !areaDoorsData.doors.length) {
      return;
    }

    const doorCoords = areaDoorsData.doors
      .map((door) => door?.coord4326)
      .filter((coords) => Array.isArray(coords) && coords.length >= 2)
      .map(([lon, lat]) => ({ lon, lat }))
      .filter(({ lon, lat }) => typeof lon === 'number' && typeof lat === 'number');

    if (!doorCoords.length) {
      return;
    }

    const minLon = Math.min(...doorCoords.map(({ lon }) => lon));
    const maxLon = Math.max(...doorCoords.map(({ lon }) => lon));
    const minLat = Math.min(...doorCoords.map(({ lat }) => lat));
    const maxLat = Math.max(...doorCoords.map(({ lat }) => lat));

    if (minLon === maxLon && minLat === maxLat) {
      setViewState((prev) => ({
        ...prev,
        longitude: minLon,
        latitude: minLat,
        zoom: Math.max(prev.zoom, 19)
      }));
      return;
    }

    if (typeof window === 'undefined') {
      return;
    }

    const viewport = calculateViewForBounds(
      { minLon, maxLon, minLat, maxLat },
      {
        width: window.innerWidth || 800,
        height: window.innerHeight || 600,
        padding: 80,
        maxZoom: 19
      }
    );

    setViewState((prev) => ({
      ...prev,
      longitude: viewport.longitude,
      latitude: viewport.latitude,
      zoom: viewport.zoom
    }));
  }, [areaDoorsData?.doors, calculateViewForBounds]);

  const handleClick = (e) => {
    if (isSelectingLocation) {
      const { lng, lat } = e.lngLat;
      const c = { lat, lng };
      setSelectedCoords(c);

      let closestFeature = null;
      if (pointFeatures.length) {
        let minDist = Infinity;
        pointFeatures.forEach((f) => {
          const [flng, flat] = f.geometry.coordinates || [];
          if (typeof flng !== 'number' || typeof flat !== 'number') {
            return;
          }
          const d = Math.hypot(flng - lng, flat - lat);
          if (d < minDist) {
            minDist = d;
            closestFeature = f;
          }
        });
        if (minDist > 0.0005) {
          closestFeature = null;
        }
      }


      if (onMapClick) onMapClick(c, closestFeature);
    } else {

      const { lng, lat } = e.lngLat;
      const c = { lat, lng };

      let closestFeature = null;
      if (pointFeatures.length) {
        let minDist = Infinity;
        pointFeatures.forEach((f) => {
          const [flng, flat] = f.geometry.coordinates || [];
          if (typeof flng !== 'number' || typeof flat !== 'number') {
            return;
          }
          const d = Math.hypot(flng - lng, flat - lat);
          if (d < minDist) {
            minDist = d;
            closestFeature = f;
          }
        });
        if (minDist > 0.0005) {
          closestFeature = null;
        }
      }


      if (onMapClick) onMapClick(c, closestFeature);
    }
  };

  const shouldLoadGeoJson = Boolean(
    selectedCategory ||
    (userCoords && destCoords) ||
    isSelectingLocation
  );

  const categoryIdToGroup = {
    1: 'sahn',
    'groupCourtyardPlural': 'sahn',
    'groupCourtyard': 'sahn',
    'groupCourtyards': 'sahn',
    2: 'eyvan',
    'groupEyvanPlural': 'eyvan',
    'groupEyvan': 'eyvan',
    3: 'ravaq',
    'groupRavaqPlural': 'ravaq',
    'groupRavaq': 'ravaq',
    4: 'masjed',
    'groupMosques': 'masjed',
    'groupMosque': 'masjed',
    5: 'madrese',
    'groupSchools': 'madrese',
    'groupSchool': 'madrese',
    6: 'khadamat',
    'groupServices': 'khadamat',
    'groupService': 'khadamat',
    7: 'elmi',
    'groupCulture': 'elmi',
    'groupCultural': 'elmi',
    8: 'cemetery',
    'groupCemetery': 'cemetery',
    9: 'qrcode',
    'groupQRScan': 'qrcode',
    'qr': 'qrcode',
    'qr-code': 'qrcode',
    10: 'elevator',
    'groupElevator': 'elevator',
    11: 'other',
    'groupOther': 'other'
  };

  const normalizeCandidateValues = (values) => {
    const set = new Set();

    values.forEach((val) => {
      if (val === undefined || val === null) return;
      const strVal = String(val);
      set.add(strVal);

      const mapped = categoryIdToGroup[val] ?? categoryIdToGroup[strVal];
      if (mapped) {
        set.add(String(mapped));
      }
    });

    return Array.from(set);
  };

  useEffect(() => {
    if (!isSelectingLocation) {
      setSelectedCoords(null);
    }
  }, [isSelectingLocation]);

  const matchesSelectedCategory = useCallback((place) => {
    if (!selectedCategory) return true;

    const selectedValue = selectedCategory.value
      ?? selectedCategory.id
      ?? selectedCategory.categories_leaf_id
      ?? selectedCategory.code;

    if (selectedValue == null) return true;

    const selectedCandidates = normalizeCandidateValues([
      selectedValue,
      selectedCategory.group,
      selectedCategory.name,
      selectedCategory.title,
      selectedCategory.label,
      selectedCategory.code,
      categoryIdToGroup[selectedValue]
    ]);

    const propertyKey =
      selectedCategory.property ||
      selectedCategory.property_target ||
      selectedCategory.propertyTarget;

    const candidateValues = normalizeCandidateValues([
      propertyKey ? place?.[propertyKey] : undefined,
      place?.categories_leaf_id,
      place?.category_leaf_id,
      place?.categoryLeafId,
      place?.category_id,
      place?.categoryId,
      place?.category,
      place?.subGroup,
      place?.subgroup,
      place?.sub_group,
      place?.subGroupValue,
      place?.subgroupValue,
      place?.sub_group_value,
      place?.group,
      place?.nodeFunction
    ]);

    return selectedCandidates.some((selected) => candidateValues.includes(selected));
  }, [selectedCategory]);

  const renderLandmarkMarkers = useCallback(() => {
    // Check if landmarks should be displayed
    const shouldShowLandmarks = isChoosingFromMap || (showImageMarkers && selectedCategory);

    if (!shouldShowLandmarks || !Array.isArray(landmarkPlaces) || landmarkPlaces.length === 0) {
      return null;
    }

    const filteredLandmarks = isChoosingFromMap
      ? landmarkPlaces  // Show all landmarks when choosing from map
      : landmarkPlaces.filter(matchesSelectedCategory);  // Filter by category when category is selected

    if (filteredLandmarks.length === 0) {
      return null;
    }

    const seenCoords = new Set();

    const markers = filteredLandmarks
      .map((place, idx) => {
        const coords = extractPlaceCoordinates(place);
        const imageUrl = getFirstImage(place);

        if (!coords || !imageUrl) return null;

        const key = place.id ? `landmark-${place.id}` : `landmark-${idx}`;
        const coordKey = `${coords.lng.toFixed(6)}-${coords.lat.toFixed(6)}`;

        if (seenCoords.has(coordKey)) return null;
        seenCoords.add(coordKey);

        return { key, coords, imageUrl, title: place.title || place.name || place.subGroup, place };
      })
      .filter(Boolean);

    return markers.map(({ key, coords, imageUrl, title, place }) => {
      // SIMPLE: Check if coordinates match selectedLandmarkId
      const coordsId = `${coords.lat.toFixed(6)},${coords.lng.toFixed(6)}`;
      const isSelected = selectedLandmarkId === coordsId;

      console.log('Landmark render check:', {
        title,
        coordsId,
        selectedLandmarkId,
        isSelected
      });

      return (
        <Marker key={key} longitude={coords.lng} latitude={coords.lat} anchor="center">
          <div
            className={`image-marker-container ${isSelected ? 'selected' : ''}`}
            onClick={(event) => handleLandmarkClick(event, place, coords)}
          >
            {/* Landmark pin SVG */}
            <svg width="40" height="47" viewBox="0 0 55 63" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M54.6562 27.3281C54.6562 39.6299 46.5275 50.0319 35.3486 53.459C35.1079 53.8493 34.8535 54.2605 34.585 54.6924L33.1699 56.9687C30.7353 60.8845 29.5175 62.8418 27.7412 62.8418C25.9651 62.8417 24.7479 60.8842 22.3135 56.9687L20.8975 54.6924C20.6938 54.3648 20.4993 54.0485 20.3115 53.7451C8.61859 50.6476 8.59898e-05 39.9953 -1.19455e-06 27.3281C-5.34814e-07 12.2351 12.2351 -1.85429e-06 27.3281 -1.19455e-06C42.4211 0.000106671 54.6562 12.2352 54.6562 27.3281Z"
                fill="white"
                stroke={isSelected ? "#1E90FF" : "#DDD"}
                strokeWidth={isSelected ? "2" : "1"}
              />
            </svg>

            {/* Image inside pin */}
            <div
              className="image-marker-content"
              style={{
                backgroundImage: `url(${imageUrl})`,
              }}
              aria-label={title || 'landmark'}
            />

            {/* Pulsing rings - only shown when selected */}
            {isSelected && (
              <>
                <div className="landmark-pulse-ring"></div>
                <div className="landmark-pulse-ring2"></div>
              </>
            )}
          </div>
        </Marker>
      );
    });
  }, [showImageMarkers, landmarkPlaces, extractPlaceCoordinates, getFirstImage, onMapClick, matchesSelectedCategory, isChoosingFromMap, selectedCategory, selectedLandmarkId, onLandmarkSelect]);

  useEffect(() => {
    if (!shouldLoadGeoJson) {
      setPointFeatures([]);
      setDoorConnectionNodes([]);
      return;
    }

    let isMounted = true;
    const controller = new AbortController();

    loadGeoJsonData({ language, signal: controller.signal })
      .then(data => {
        if (!isMounted) {
          return;
        }

        const features = Array.isArray(data?.features) ? data.features : [];
        const nextPointFeatures = features.filter((f) => {
          if (f.geometry?.type !== 'Point') {
            return false;
          }
          const nodeFn = f.properties?.nodeFunction;
          return nodeFn !== 'door' && nodeFn !== 'connection';
        });

        const nextDoorNodes = features.filter(
          (f) =>
            f.geometry?.type === 'Point' &&
            ['door', 'connection'].includes(f.properties?.nodeFunction)
        );

        setPointFeatures(nextPointFeatures);
        setDoorConnectionNodes(nextDoorNodes);
      })
      .catch(err => {
        if (err?.name === 'AbortError') return;
        console.error('failed to load geojson', err);
      });

    return () => {
      isMounted = false;
      controller.abort();
    };
  }, [language, shouldLoadGeoJson]);

  useEffect(() => {
    if (userCoords && destCoords && doorConnectionNodes.length) {
      const points = doorConnectionNodes;
      const nearest = (coords) => {
        let best = null;
        let dmin = Infinity;
        points.forEach((p) => {
          const [lng, lat] = p.geometry.coordinates;
          const d = Math.hypot(lng - coords.lng, lat - coords.lat);
          if (d < dmin) {
            dmin = d;
            best = { lng, lat };
          }
        });
        return best;
      };

      const start = nearest(userCoords);
      const end = nearest(destCoords);
      const coords = [
        [userCoords.lng, userCoords.lat],
        ...(start ? [[start.lng, start.lat]] : []),
        ...(end ? [[end.lng, end.lat]] : []),
        [destCoords.lng, destCoords.lat]
      ];
      setRouteCoords(coords);
    } else {
      setRouteCoords(null);
    }
  }, [userCoords, destCoords, doorConnectionNodes]);

  return (
    <Map
      key={mapRenderKey}
      mapLib={maplibregl}
      mapStyle={mapStyle}
      styleDiffing={false}
      style={{ width: '100%', height: '100%' }}
      {...viewState}
      onMove={onMove}
      onLoad={handleMapLoad}
      onClick={handleClick}
      onError={isSatellite ? undefined : handleMapError}
      interactive={true}
    >
      {/* User location marker */}
      {userCoords && (
        <Marker longitude={userCoords.lng} latitude={userCoords.lat} anchor="center">
          <div className="map-marker-origin">
          </div>
        </Marker>
      )}

      {/* Destination marker */}
      {destCoords && (
        <Marker longitude={destCoords.lng} latitude={destCoords.lat} anchor="bottom">
          <div className="map-marker-destination">
            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#F44336">
              <path d="M18.364 4.636a9 9 0 0 1 .203 12.519l-.203 .21l-4.243 4.242a3 3 0 0 1 -4.097 .135l-.144 -.135l-4.244 -4.243a9 9 0 0 1 12.728 -12.728zm-6.364 3.364a3 3 0 1 0 0 6a3 3 0 1 0 0 -6z" />
            </svg>
          </div>
        </Marker>
      )}

      {/* Temporary selection marker when choosing location */}
      {selectedCoords && isSelectingLocation && (
        <Marker longitude={selectedCoords.lng} latitude={selectedCoords.lat} anchor="bottom">
          <div className="map-marker-selecting">
            <div className="map-marker-selecting-inner" />
          </div>
        </Marker>
      )}

      {/* Route line */}
      {routeCoords && (
        <Source id="route" type="geojson" data={{ type: 'Feature', geometry: { type: 'LineString', coordinates: routeCoords } }}>
          <Layer id="route-line" type="line" paint={{ 'line-color': '#4285F4', 'line-width': 4, 'line-opacity': 0.7 }} />
        </Source>
      )}

      {renderLandmarkMarkers()}

      {/* Point features (doors, services, etc.) */}
      {selectedCategory && pointFeatures
        .filter((feature) => matchesSelectedCategory(feature?.properties || {}))
        .filter((feature) => !['door', 'connection'].includes(feature?.properties?.nodeFunction))
        .map((feature, idx) => {
          const [lng, lat] = feature.geometry.coordinates;
          const { group, nodeFunction } = feature.properties || {};

          const rawId = feature.properties?.uniqueId;
          const key = rawId ? `${rawId}-${idx}` : idx;

          return (
            <Marker key={key} longitude={lng} latitude={lat} anchor="center">
              <div style={{ position: 'relative' }}>
                {getCompositeIcon(groups, group, nodeFunction, 40, 1)}
                <div
                  style={{
                    position: 'absolute',
                    top: -4,
                    left: -4,
                    right: -4,
                    bottom: -4,
                    border: '2px solid #e53935',
                    borderRadius: '50%'
                  }}
                />
              </div>
            </Marker>
          );
        })}
    </Map>
  );
};

export default Mprc;
